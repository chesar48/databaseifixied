module.exports = {
    'secret' : 'rahasiaku',
    
}