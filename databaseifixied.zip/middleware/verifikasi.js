const jwt = require("jsonwebtoken");
const config = require("../config/secret");

function verifikasi(roles){
    return function (req,res, next){
        //cek autorisasi header
    }
}